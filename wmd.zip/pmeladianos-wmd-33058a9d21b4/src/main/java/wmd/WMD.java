package wmd;


import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.api.ops.impl.accum.distances.EuclideanDistance;
import org.nd4j.linalg.factory.Nd4j;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static java.lang.Math.max;

/**
 * Created by Midas on 9/20/2016.
 */
public class WMD {
    HashMap<String,List<Double>> dictionary;
    Integer dimensions;
    public static void main(String... args) {
        String f1 = args[0];
        String f2 = args[1];
        String f3 = args[2];
        WMD wmd=new WMD();
        wmd.loadDictionary(f3);
        File file1 = new File(f1);
        File file2 = new File(f2);
        if (file1.isFile() &&  file2.isFile() ){
            System.out.println(wmd.compareDocuments(f1,f2));
        }
        else if (file1.isDirectory() &&  file2.isDirectory()){

            Double sum=0.0;
            String path2 = file2.getAbsolutePath();
            File[] files = file1.listFiles();
            double counter = 0.0;
            for (File file:files){
                File other_file = new File(path2+"/" + file.getName());
                sum+=wmd.compareDocuments(file.getAbsolutePath(),other_file.getAbsolutePath());
                counter+=1.0;
            }
            System.out.println("macro average wmd"+sum/counter);
        }

    }

    private void loadDictionary(String f3) {
        dictionary=new HashMap();
        List<String> lines_3 = null;
        try {
            lines_3 = Files.readAllLines(Paths.get(f3));
        } catch (IOException e) {
            System.out.println(e);
        }
        lines_3.forEach(l->{
            String[] tokens = l.split(",");
            String key = tokens[0];
            String[] values=tokens[1].split(" ");
            List<Double> vector=new ArrayList();
            for (String val:values){
                vector.add(Double.valueOf(val));
            }
            this.dimensions=vector.size();
            this.dictionary.put(key,vector);
        });
    }


    public Double compareDocuments(String path1,String path2){
        List<String> lines_1 = null;
        List<String> lines_2 = null;
        try {
            lines_1 = Files.readAllLines(Paths.get(path1));
            lines_2 = Files.readAllLines(Paths.get(path2));

        } catch (IOException e) {
            System.out.println(e);
        }
        List<String> words1 = new ArrayList<>();
        List<String> words2 = new ArrayList<>();
        lines_1.forEach(l->{
            String[] tokens = l.split(" ");
            for(String token:tokens)
                words1.add(token);
        });
        lines_2.forEach(l->{
            String[] tokens = l.split(" ");
            for(String token:tokens)
                words2.add(token);
        });
    return calculateWMD(words1,words2);
    }

    private Double calculateWMD(List<String> l1, List<String> l2) {

        List<double[]> vectorsA = new ArrayList<>();
        List<double[]> vectorsB = new ArrayList<>();
        for (String s : l1) {
            double[] temp = new double[this.dimensions];//PretrainedVectors.getWordVectors().getWordVector(s);
            if (this.dictionary.containsKey(s)) {
                int c = 0;
                for (Double v:this.dictionary.get(s)){
                    temp[c]=v;
                    c++;
                }
                vectorsA.add(temp);
            }
        }
        for (String s : l2) {
            double[] temp = new double[this.dimensions];//PretrainedVectors.getWordVectors().getWordVector(s);
            if (this.dictionary.containsKey(s)) {
                int c = 0;
                for (Double v:this.dictionary.get(s)){
                    temp[c]=v;
                    c++;
                }
                vectorsB.add(temp);
            }
        }
        int maxl = max(vectorsA.size(), vectorsB.size());
        double[][] distances = new double[maxl][maxl];
        double[] P = new double[maxl];
        double[] Q = new double[maxl];
        if (vectorsA.size() == 0 || vectorsB.size() == 0)
            return -100.0;
        for (int ii = 0; ii < maxl; ii++) {
            if (ii < vectorsA.size()) {
                P[ii] = 1 / (double) vectorsA.size();
                for (int jj = 0; jj < maxl; jj++) {
                    if (jj < vectorsB.size()) {
                        Q[jj] = 1 / (double) vectorsB.size();
                        distances[ii][jj] = pdist2(vectorsA.get(ii), vectorsB.get(jj));
                    }
                }
            }
        }
        double res=-100.0;
        try {
            Class<?> c = Class.forName("emd_hat");
            Method[] m = c.getDeclaredMethods();
            Method method = c.getMethod("dist_gd_metric",double[].class, double[].class, double[][].class, double.class ,double[][].class);
            res= (double)method.invoke(this, (Object)P,(Object)Q,(Object)distances,0,null);
        } catch (Exception e) {
            System.out.println("native call Exception");
            System.out.println(Arrays.toString(P));
            System.out.println(Arrays.toString(Q));
            e.printStackTrace();
        }
        return res;
    }

    private Double pdist2(double[] vec1,double[] vec2) {
        INDArray x = Nd4j.create(vec1);	//input
        INDArray y = Nd4j.create(vec2);
        EuclideanDistance dist = new EuclideanDistance();
        dist.setX(x);
        dist.setY(y);
        INDArray distanceResult = Nd4j.getExecutioner().exec(Nd4j.getOpFactory().createAccum("euclidean", x, y), 1);
        return distanceResult.getDouble(0);
    }
    private static double[] randomDoubleArray(int N) {
        double[] randArr= new double[N];
        Random generator = new Random();
        for (int i= 0; i<N; ++i) {
            randArr[i]= generator.nextDouble();
        }
        return randArr;
    }
}
